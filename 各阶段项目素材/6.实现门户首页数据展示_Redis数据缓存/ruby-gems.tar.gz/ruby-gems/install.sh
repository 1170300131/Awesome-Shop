#!/bin/sh
rpm -ivh compat-readline5-5.2-17.1.el6.x86_64.rpm
rpm -ivh ruby-libs-1.8.7.374-4.el6_6.x86_64.rpm
rpm -ivh ruby-1.8.7.374-4.el6_6.x86_64.rpm
rpm -ivh ruby-irb-1.8.7.374-4.el6_6.x86_64.rpm
rpm -ivh ruby-rdoc-1.8.7.374-4.el6_6.x86_64.rpm
rpm -ivh rubygems-1.3.7-5.el6.noarch.rpm
gem install -l redis-3.0.6.gem
